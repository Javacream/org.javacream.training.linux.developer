package org.javacream.books.warehouse.repository;

public interface BooksRepositoryOperations {
	
	void discountPrices(double discount);

}
