create table CONTENT (resourceid varchar(128), content varchar(512), primary key (resourceid))
insert into CONTENT (resourceid, content) values('ISBN1', 'a great book about java')
insert into CONTENT (resourceid, content) values('ISBN2', 'a great book about helgoland')

