package org.javacream.util.log.api;

public interface LogService {
	public void log(String message);

}
