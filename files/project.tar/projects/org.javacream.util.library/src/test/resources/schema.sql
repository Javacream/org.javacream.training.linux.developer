create table LOGS (log varchar(512))
