insert into STORE (category, item, stock) values('books', 'ISBN1', 42)
insert into STORE (category, item, stock) values('books', 'ISBN2', 2)
insert into STORE (category, item, stock) values('books', 'ISBN3', 4)
insert into STORE (category, item, stock) values('dvd', 'Star Trek', 5)
insert into STORE (category, item, stock) values('cd', 'Sergeant Pepper', 12)

