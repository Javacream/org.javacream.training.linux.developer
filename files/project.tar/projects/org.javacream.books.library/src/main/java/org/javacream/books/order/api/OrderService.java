package org.javacream.books.order.api;

public interface OrderService {
	
	public OrderEntity order(String isbn, int number);

}
