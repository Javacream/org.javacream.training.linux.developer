package org.javacream.books.order.api;

public enum OrderStatus {
	OK, PENDING, UNAVAILABLE;
}
