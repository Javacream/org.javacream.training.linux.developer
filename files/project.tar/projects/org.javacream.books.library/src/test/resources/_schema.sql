create table STORE (category varchar(128), item varchar(128), stock integer, primary key (category, item))
create table ISBNS (isbn integer)
create table LOGS (log varchar(512))
